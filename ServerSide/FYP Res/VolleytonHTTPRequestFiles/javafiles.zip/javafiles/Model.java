package com.ascomp.database_prac;

public class Model {
    String id;
    String title;

    public Model(String id, String title){
        this.id=id;
        this.title=title;
    }
}
